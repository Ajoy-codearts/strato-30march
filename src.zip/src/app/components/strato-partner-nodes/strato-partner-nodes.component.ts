import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-strato-partner-nodes',
  templateUrl: './strato-partner-nodes.component.html',
  styleUrls: ['./strato-partner-nodes.component.scss']
})
export class StratoPartnerNodesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
