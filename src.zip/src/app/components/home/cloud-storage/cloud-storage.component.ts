import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cloud-storage',
  templateUrl: './cloud-storage.component.html',
  styleUrls: ['./cloud-storage.component.scss']
})
export class CloudStorageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
