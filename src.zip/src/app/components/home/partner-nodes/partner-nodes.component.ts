import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partner-nodes',
  templateUrl: './partner-nodes.component.html',
  styleUrls: ['./partner-nodes.component.scss']
})
export class PartnerNodesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
