import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-strato-partner-nodes-license',
  templateUrl: './strato-partner-nodes-license.component.html',
  styleUrls: ['./strato-partner-nodes-license.component.scss']
})
export class StratoPartnerNodesLicenseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
